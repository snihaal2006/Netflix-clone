
import React, { useState } from 'react';
import { Movie } from '../types';

interface MovieCardProps {
  movie: Movie;
  onClick: (movie: Movie) => void;
}

const MovieCard: React.FC<MovieCardProps> = ({ movie, onClick }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className="video-card group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={() => onClick(movie)}
    >
      {/* Default Thumbnail */}
      <img 
        src={movie.backdropUrl} 
        alt={movie.title}
        className="video-thumbnail shadow-lg"
      />

      {/* Expanded Netflix Hover Card */}
      {isHovered && (
        <div className="hover-card-container">
          {/* Top Preview Section */}
          <div className="relative">
            <img src={movie.backdropUrl} alt={movie.title} className="hover-preview-image" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#181818]/80 via-transparent to-transparent" />
            
            {/* Title Overlay (Matching the image font style) */}
            <div className="absolute bottom-2 left-3 text-white font-black text-2xl uppercase italic tracking-tighter drop-shadow-xl">
              {movie.title}
            </div>

            {/* Mute Icon (Bottom Right of Media) */}
            <div className="absolute bottom-3 right-3 p-1.5 rounded-full border border-white/40 text-white/70">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg>
            </div>
          </div>

          {/* Bottom Info Section */}
          <div className="hover-info-section">
            {/* Action Row */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button className="icon-button play-button">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"></path></svg>
                </button>
                <button className="icon-button">
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                </button>
                <button className="icon-button">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path></svg>
                </button>
              </div>
              <button className="icon-button">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="6 9 12 15 18 9"></polyline></svg>
              </button>
            </div>

            {/* Metadata Row */}
            <div className="flex items-center gap-2 text-[12px] font-bold text-white/80">
              <span className="badge">U/A 16+</span>
              <span>{movie.duration}</span>
              <span className="badge text-[8px] px-1 rounded-sm">HD</span>
              <div className="flex items-center gap-1 text-white/60">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><path d="M12 18V12l-4-2"></path><path d="M16 10l-4 2"></path><circle cx="12" cy="12" r="3"></circle></svg>
                <span className="text-[9px]">Spatial Audio</span>
              </div>
            </div>

            {/* Genres Row */}
            <div className="flex items-center gap-2 text-[12px] font-semibold text-white/90">
              {movie.genres.map((genre, idx) => (
                <React.Fragment key={genre}>
                  <span>{genre}</span>
                  {idx < movie.genres.length - 1 && (
                    <span className="text-white/40">•</span>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MovieCard;

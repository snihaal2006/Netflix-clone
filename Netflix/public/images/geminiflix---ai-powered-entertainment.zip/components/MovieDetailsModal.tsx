
import React from 'react';
import { Movie } from '../types';

interface MovieDetailsModalProps {
  movie: Movie | null;
  onClose: () => void;
  onPlay: (movie: Movie) => void;
}

const MovieDetailsModal: React.FC<MovieDetailsModalProps> = ({ movie, onClose, onPlay }) => {
  if (!movie) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8 overflow-y-auto bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-4xl bg-[#181818] rounded-lg overflow-hidden animate-in fade-in zoom-in duration-300">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-50 p-2 bg-black/60 text-white rounded-full hover:bg-black transition"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>

        <div className="relative h-[300px] md:h-[450px]">
          <img src={movie.backdropUrl} alt={movie.title} className="w-full h-full object-cover brightness-[60%]" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#181818] to-transparent" />
          
          <div className="absolute bottom-8 left-8 space-y-4">
            <h2 className="text-3xl md:text-5xl font-black">{movie.title}</h2>
            <div className="flex items-center gap-4">
              <button 
                onClick={() => onPlay(movie)}
                className="bg-white text-black px-8 py-2 rounded flex items-center gap-2 font-bold hover:bg-white/90 transition"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"></path></svg>
                Play
              </button>
              <button className="p-2 border-2 border-white/30 text-white rounded-full hover:bg-white/10 transition">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
              </button>
            </div>
          </div>
        </div>

        <div className="p-8 grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-3 font-semibold text-sm">
              <span className="text-green-500">{movie.rating.toFixed(1)} Rating</span>
              <span className="text-gray-400">{movie.releaseYear}</span>
              <span className="text-gray-400">{movie.duration}</span>
              <span className="border border-gray-600 px-1.5 py-0.5 rounded text-[10px]">HD</span>
            </div>
            <p className="text-lg leading-relaxed text-gray-200">
              {movie.description}
            </p>
          </div>
          
          <div className="space-y-4 text-sm">
            <div>
              <span className="text-gray-500">Genres:</span>{' '}
              <span className="text-gray-200">{movie.genres.join(', ')}</span>
            </div>
            <div>
              <span className="text-gray-500">Available in:</span>{' '}
              <span className="text-gray-200">English, Spanish, French, Japanese</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieDetailsModal;

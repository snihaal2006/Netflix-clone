
import { GoogleGenAI, Type } from "@google/genai";
import { Movie } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const MOVIE_SCHEMA = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      id: { type: Type.STRING },
      title: { type: Type.STRING },
      description: { type: Type.STRING },
      rating: { type: Type.NUMBER },
      releaseYear: { type: Type.INTEGER },
      duration: { type: Type.STRING },
      genres: { type: Type.ARRAY, items: { type: Type.STRING } },
      backdropUrl: { type: Type.STRING },
      posterUrl: { type: Type.STRING },
      matchScore: { type: Type.INTEGER }
    },
    required: ["id", "title", "description", "rating", "releaseYear", "duration", "genres", "backdropUrl", "posterUrl"]
  }
};

export const getMoviesByCategory = async (category: string): Promise<Movie[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate a list of 10 popular/realistic movies or TV shows for the category: "${category}". 
      Return high-quality placeholder image URLs from picsum.photos for backdropUrl (1280x720) and posterUrl (500x750).
      Ensure they are unique and relevant.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: MOVIE_SCHEMA
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Error fetching movies from Gemini:", error);
    return [];
  }
};

export const searchMovies = async (query: string): Promise<Movie[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Search for movies related to: "${query}". Provide 6 results.
      Return high-quality placeholder image URLs from picsum.photos for backdropUrl and posterUrl.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: MOVIE_SCHEMA
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Error searching movies:", error);
    return [];
  }
};

export const getAIRecommendations = async (userPrompt: string): Promise<Movie[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `The user says: "${userPrompt}". Based on this, suggest 5 highly personalized movie recommendations. 
      Include a "matchScore" between 80 and 99.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: MOVIE_SCHEMA
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Error getting AI recommendations:", error);
    return [];
  }
};
